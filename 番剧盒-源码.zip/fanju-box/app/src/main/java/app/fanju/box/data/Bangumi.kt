package app.fanju.box.data

import app.fanju.box.player.DanmakuItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Bangumi 公开 API：用文件夹名搜索条目，取中文名、简介、封面、评分。
 * 不需要服务器，也不需要账号。
 */
object Bangumi {
    private const val UA = "FanjuBox/1.0 (Android; metadata scraper)"
    private const val API = "https://api.bgm.tv"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    suspend fun search(keyword: String, limit: Int = 8): List<BgmSubject> = withContext(Dispatchers.IO) {
        val kw = keyword.trim()
        if (kw.isEmpty()) return@withContext emptyList()
        val body = """{"keyword":${JSONObject.quote(kw)},"filter":{"type":[2]}}"""
        var list = post("/v0/search/subjects?limit=$limit", body)
        if (list.isEmpty()) list = post("/v0/search/subjects?limit=$limit", """{"keyword":${JSONObject.quote(kw)}}""")
        if (list.isEmpty()) list = legacySearch(kw)
        list
    }

    private fun post(path: String, body: String): List<BgmSubject> {
        return try {
            val req = Request.Builder()
                .url(API + path)
                .post(body.toRequestBody("application/json".toMediaType()))
                .header("User-Agent", UA)
                .header("Accept", "application/json")
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return emptyList()
                val text = resp.body?.string() ?: return emptyList()
                val root = JSONObject(text)
                val arr = root.optJSONArray("data") ?: return emptyList()
                (0 until arr.length()).map { parseSubject(arr.getJSONObject(it)) }
            }
        } catch (_: Throwable) {
            emptyList()
        }
    }

    private fun legacySearch(keyword: String): List<BgmSubject> {
        return try {
            val url = "$API/search/subject/" + java.net.URLEncoder.encode(keyword, "UTF-8") +
                "?type=2&responseGroup=large&max_results=8"
            val req = Request.Builder().url(url).header("User-Agent", UA).get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return emptyList()
                val root = JSONObject(resp.body?.string() ?: return emptyList())
                val arr = root.optJSONArray("list") ?: return emptyList()
                (0 until arr.length()).map { parseSubject(arr.getJSONObject(it)) }
            }
        } catch (_: Throwable) {
            emptyList()
        }
    }

    suspend fun subject(id: Int): BgmSubject? = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url("$API/v0/subjects/$id")
                .header("User-Agent", UA).get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext null
                val text = resp.body?.string() ?: return@withContext null
                parseSubject(JSONObject(text))
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun parseSubject(o: JSONObject): BgmSubject {
        val images = o.optJSONObject("images")
        val rating = o.optJSONObject("rating")
        return BgmSubject(
            id = o.optInt("id"),
            name = o.optString("name"),
            nameCn = o.optString("name_cn"),
            summary = o.optString("summary").replace("\r\n", "\n").trim(),
            poster = images?.optString("large").orEmpty().ifBlank { images?.optString("common").orEmpty() },
            score = rating?.optDouble("score", 0.0) ?: 0.0,
            date = o.optString("date")
        )
    }

    suspend fun downloadPoster(url: String, dest: File): Boolean = withContext(Dispatchers.IO) {
        if (url.isBlank()) return@withContext false
        try {
            dest.parentFile?.mkdirs()
            val req = Request.Builder().url(url)
                .header("User-Agent", UA)
                .header("Referer", "https://bgm.tv/")
                .get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext false
                val body = resp.body ?: return@withContext false
                dest.outputStream().use { out -> body.byteStream().copyTo(out) }
            }
            dest.length() > 1024
        } catch (_: Throwable) {
            false
        }
    }
}

/**
 * 弹弹play 网络弹幕（可选）：用于按番剧名匹配剧集并拉取弹幕。
 * 需要在设置里填写自己的 AppId / AppSecret。
 */
object Dandanplay {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    data class Hit(val episodeId: Long, val animeTitle: String, val episodeTitle: String)

    private fun base(s: AppSettings) = s.danmakuBaseUrl.ifBlank { "https://api.dandanplay.net" }.trimEnd('/')

    suspend fun search(settings: AppSettings, name: String): List<Hit> = withContext(Dispatchers.IO) {
        if (settings.danmakuAppId.isBlank() || settings.danmakuAppSecret.isBlank()) return@withContext emptyList()
        try {
            val url = base(settings) + "/api/v2/search/episodes?anime=" + java.net.URLEncoder.encode(name, "UTF-8")
            val req = Request.Builder().url(url)
                .header("X-AppId", settings.danmakuAppId)
                .header("X-AppSecret", settings.danmakuAppSecret)
                .header("Accept", "application/json")
                .get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext emptyList()
                val root = JSONObject(resp.body?.string() ?: return@withContext emptyList())
                val animes = root.optJSONArray("animes") ?: return@withContext emptyList()
                val out = mutableListOf<Hit>()
                for (i in 0 until animes.length()) {
                    val a = animes.getJSONObject(i)
                    val title = a.optString("animeTitle")
                    val eps = a.optJSONArray("episodes") ?: continue
                    for (j in 0 until eps.length()) {
                        val e = eps.getJSONObject(j)
                        out.add(Hit(e.optLong("episodeId"), title, e.optString("episodeTitle")))
                    }
                }
                out
            }
        } catch (_: Throwable) {
            emptyList()
        }
    }

    suspend fun comment(settings: AppSettings, episodeId: Long): List<DanmakuItem> = withContext(Dispatchers.IO) {
        if (settings.danmakuAppId.isBlank() || settings.danmakuAppSecret.isBlank()) return@withContext emptyList()
        try {
            val url = base(settings) + "/api/v2/comment/$episodeId?withRelated=true&chConvert=0"
            val req = Request.Builder().url(url)
                .header("X-AppId", settings.danmakuAppId)
                .header("X-AppSecret", settings.danmakuAppSecret)
                .header("Accept", "application/json")
                .get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext emptyList()
                val root = JSONObject(resp.body?.string() ?: return@withContext emptyList())
                val arr = root.optJSONArray("comments") ?: return@withContext emptyList()
                val out = mutableListOf<DanmakuItem>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val p = o.optString("p")
                    val m = o.optString("m")
                    val parts = p.split(',')
                    val t = parts.getOrNull(0)?.toDoubleOrNull() ?: continue
                    if (m.isBlank()) continue
                    out.add(
                        DanmakuItem(
                            timeMs = (t * 1000).toLong(),
                            mode = parts.getOrNull(1)?.toIntOrNull() ?: 1,
                            color = parts.getOrNull(2)?.toIntOrNull() ?: 0xFFFFFF,
                            sizeSp = 20,
                            text = m.trim()
                        )
                    )
                }
                out
            }
        } catch (_: Throwable) {
            emptyList()
        }
    }
}
