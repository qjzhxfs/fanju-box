package app.fanju.box.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.fanju.box.data.Repo
import app.fanju.box.data.Work
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(onOpenWork: (String) -> Unit, onOpenSettings: () -> Unit) {
    val works by Repo.works.collectAsState()
    val sources by Repo.sources.collectAsState()
    val scan by Repo.scan.collectAsState()
    val settings by Repo.settings.collectAsState()
    val scope = rememberCoroutineScope()
    var showAdd by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    fun startScan() {
        if (scan.running) return
        scope.launch {
            busy = "正在扫描媒体源…"
            val err = Repo.rescan()
            if (err != null) {
                busy = null
                message = err
                return@launch
            }
            if (settings.scrapeEnabled && sources.isNotEmpty()) {
                busy = "正在刮削海报与简介…"
                Repo.scrapeMissing { t -> busy = t }
            }
            busy = null
            message = if (Repo.works.value.isEmpty()) "没有找到视频文件" else null
        }
    }

    LaunchedEffect(Unit) {
        if (sources.isNotEmpty() && settings.autoScanOnStart && works.isEmpty()) {
            startScan()
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 6.dp, top = 12.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "番剧盒",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { startScan() }) {
                Icon(Icons.Default.Refresh, contentDescription = "扫描", tint = MaterialTheme.colorScheme.onSurface)
            }
            IconButton(onClick = { showAdd = true }) {
                Icon(Icons.Default.Add, contentDescription = "添加媒体源", tint = MaterialTheme.colorScheme.onSurface)
            }
            IconButton(onClick = onOpenSettings) {
                Icon(Icons.Default.Settings, contentDescription = "设置", tint = MaterialTheme.colorScheme.onSurface)
            }
        }

        if (busy != null || scan.running) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                Text(
                    busy ?: scan.message,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        } else if (message != null) {
            Text(
                message!!,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
        }

        if (works.isEmpty()) {
            EmptyHint(
                title = if (sources.isEmpty()) "还没有媒体源" else "还没有扫描到视频",
                subtitle = if (sources.isEmpty()) "添加 WebDAV 或手机本地文件夹，就能看到海报墙"
                else "点右上角刷新重新扫描",
                modifier = Modifier.fillMaxSize(),
                action = {
                    if (sources.isEmpty()) {
                        Button(onClick = { showAdd = true }) { Text("添加媒体源") }
                    }
                }
            )
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 108.dp),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(works, key = { it.id }) { work ->
                    WorkCard(work) { onOpenWork(work.id) }
                }
            }
        }
    }

    if (showAdd) {
        AddSourceDialog(onDismiss = { showAdd = false }, onSaved = {
            showAdd = false
            startScan()
        })
    }
}

@Composable
private fun WorkCard(work: Work, onClick: () -> Unit) {
    val watched = remember(work.id, work.episodes.size) {
        work.episodes.count { Repo.progressOf(it.id) > 0 }
    }
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable { onClick() }
    ) {
        Box {
            PosterImage(
                poster = work.poster,
                label = work.displayTitle,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(2f / 3f)
            )
            if (work.score > 0) {
                Text(
                    "★ ${"%.1f".format(work.score)}",
                    fontSize = 10.sp,
                    color = Gold,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(5.dp)
                        .background(androidx.compose.ui.graphics.Color(0xCC000000), RoundedCornerShape(6.dp))
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                )
            }
            if (watched > 0) {
                LinearProgressIndicator(
                    progress = { watched.toFloat() / work.episodes.size.coerceAtLeast(1) },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .height(3.dp),
                    color = Gold,
                    trackColor = androidx.compose.ui.graphics.Color(0x66000000)
                )
            }
        }
        Text(
            work.displayTitle,
            fontSize = 12.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            lineHeight = 15.sp,
            modifier = Modifier.padding(top = 6.dp, start = 2.dp, end = 2.dp)
        )
        Text(
            if (work.episodeCount > 0) "${work.episodeCount} 集" else "",
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 2.dp, top = 2.dp, bottom = 2.dp)
        )
    }
}
