package app.fanju.box.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.fanju.box.data.AppSettings
import app.fanju.box.data.Repo
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val sources by Repo.sources.collectAsState()
    val settings by Repo.settings.collectAsState()
    val works by Repo.works.collectAsState()
    val scope = rememberCoroutineScope()
    var showAdd by remember { mutableStateOf(false) }
    var rescanning by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 6.dp, end = 16.dp, top = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回", tint = MaterialTheme.colorScheme.onSurface)
            }
            Text("设置", fontSize = 20.sp, modifier = Modifier.padding(start = 4.dp))
        }

        SectionTitle("媒体源")
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            sources.forEach { src ->
                SourceRow(src, onRemove = { Repo.removeSource(src.id) })
            }
            Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) { Text("添加媒体源") }
            Spacer(Modifier.height(2.dp))
            Button(
                enabled = !rescanning && sources.isNotEmpty(),
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    scope.launch {
                        rescanning = true
                        val err = Repo.rescan()
                        if (err == null) {
                            Repo.scrapeMissing { status = it }
                            status = "扫描完成，共 ${Repo.works.value.size} 个条目"
                        } else status = err
                        rescanning = false
                    }
                }
            ) { Text(if (rescanning) "扫描中…" else "立即重新扫描") }
            status?.let { Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary) }
            Text("已收录 ${works.size} 个条目", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        SectionTitle("刮削")
        SettingSwitch(
            title = "自动刮削海报与简介",
            subtitle = "用 Bangumi 公开接口按文件夹名匹配，不需要账号",
            checked = settings.scrapeEnabled
        ) { Repo.updateSettings(settings.copy(scrapeEnabled = it)) }
        SettingSwitch(
            title = "优先使用中文名",
            subtitle = "刮削到条目后，标题显示中文译名",
            checked = settings.preferNameCn
        ) { Repo.updateSettings(settings.copy(preferNameCn = it)) }
        SettingSwitch(
            title = "启动时自动扫描",
            subtitle = "打开 App 时自动刷新媒体源",
            checked = settings.autoScanOnStart
        ) { Repo.updateSettings(settings.copy(autoScanOnStart = it)) }

        SectionTitle("弹幕")
        SettingSwitch(
            title = "默认显示弹幕",
            subtitle = "同目录的 xml / json 弹幕文件会自动加载",
            checked = settings.danmakuEnabled
        ) { Repo.updateSettings(settings.copy(danmakuEnabled = it)) }
        Column(Modifier.padding(horizontal = 16.dp)) {
            PasteField(
                value = settings.danmakuAppId,
                onValueChange = { Repo.updateSettings(settings.copy(danmakuAppId = it.trim())) },
                label = "弹弹play AppId（可选，用于网络弹幕）",
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            PasteField(
                value = settings.danmakuAppSecret,
                onValueChange = { Repo.updateSettings(settings.copy(danmakuAppSecret = it.trim())) },
                label = "弹弹play AppSecret",
                password = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            PasteField(
                value = settings.danmakuBaseUrl,
                onValueChange = { Repo.updateSettings(settings.copy(danmakuBaseUrl = it.trim())) },
                label = "弹幕服务地址（默认 https://api.dandanplay.net）",
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "不填 AppId/AppSecret 时只用本地弹幕文件；填了之后播放页可以按番剧名拉取网络弹幕。",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        SectionTitle("关于")
        Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
            Text("番剧盒 1.0", fontSize = 13.sp)
            Text(
                "WebDAV + 本地文件影视客户端：海报墙、刮削简介、弹幕、外挂字幕、断点续播。\n不需要任何服务器组件。",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.height(40.dp))
    }

    if (showAdd) {
        AddSourceDialog(onDismiss = { showAdd = false }, onSaved = { showAdd = false })
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        fontSize = 12.sp,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 16.dp, top = 20.dp, bottom = 6.dp)
    )
}

@Composable
private fun SettingSwitch(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp)
            Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
