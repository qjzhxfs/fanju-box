package app.fanju.box.data

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File

data class ScanState(
    val running: Boolean = false,
    val message: String = "",
    val done: Int = 0,
    val total: Int = 0
)

data class PlaybackSpec(
    val work: Work,
    val episode: MediaEpisode,
    val url: String,
    val headers: Map<String, String>,
    val subtitles: List<Pair<String, String>>,   // 显示名 -> 本地文件路径
    val danmakuFiles: List<String>,              // 本地 xml/json 文件路径
    val danmakuRemote: List<MediaSource>,        // 预留
    val startPositionMs: Long
)

private val JUNK_FOLDERS = setOf(
    "qq", "telegram", "wechat", "micromsg", "tencent", "camera", "dcim", "pictures",
    "screenshots", "screenrecord", "screenshot", "movie recoder", "recordings", "voice",
    "下载", "download", "cache", "temp", "tmp", "thumbnails"
)

fun isJunkFolder(name: String): Boolean {
    val n = name.trim().lowercase()
    return n.startsWith(".") || n in JUNK_FOLDERS
}

object Repo {
    private var appCtx: Context? = null
    private var store: Store? = null

    private val _sources = MutableStateFlow<List<MediaSource>>(emptyList())
    val sources: StateFlow<List<MediaSource>> = _sources.asStateFlow()

    private val _works = MutableStateFlow<List<Work>>(emptyList())
    val works: StateFlow<List<Work>> = _works.asStateFlow()

    private val _scan = MutableStateFlow(ScanState())
    val scan: StateFlow<ScanState> = _scan.asStateFlow()

    private val _settings = MutableStateFlow(AppSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private val progress = mutableMapOf<String, Long>()
    private val overrides = mutableMapOf<String, Int>()

    private fun postersDir(): File {
        val base = appCtx?.filesDir ?: File("/tmp")
        return File(base, "posters").apply { mkdirs() }
    }

    private fun subsCacheDir(): File {
        val base = appCtx?.cacheDir ?: File("/tmp")
        return File(base, "subs").apply { mkdirs() }
    }

    fun init(ctx: Context) {
        if (appCtx != null) return
        appCtx = ctx.applicationContext
        val st = Store(ctx.applicationContext)
        store = st
        _sources.value = st.loadSources()
        _works.value = st.loadWorks().sortedBy { it.displayTitle.lowercase() }
        _settings.value = st.loadSettings()
        progress.putAll(st.loadProgress())
        overrides.putAll(st.loadOverrides())
    }

    // ---------------- sources ----------------

    fun addSource(src: MediaSource) {
        val list = _sources.value.filterNot { it.id == src.id } + src
        _sources.value = list
        store?.saveSources(list)
    }

    fun removeSource(id: String) {
        val list = _sources.value.filterNot { it.id == id }
        _sources.value = list
        store?.saveSources(list)
        val remaining = _works.value.filterNot { it.sourceId == id }
        _works.value = remaining
        store?.saveWorks(remaining)
    }

    fun updateSettings(s: AppSettings) {
        _settings.value = s
        store?.saveSettings(s)
    }

    fun progressOf(episodeId: String): Long = progress[episodeId] ?: 0L

    fun setProgress(episodeId: String, ms: Long) {
        progress[episodeId] = ms
        store?.let { st ->
            // 简单防抖：直接写
            st.saveProgress(progress)
        }
    }

    fun workById(id: String): Work? = _works.value.firstOrNull { it.id == id }

    fun refreshWork(work: Work) {
        val list = _works.value.map { if (it.id == work.id) work else it }
        _works.value = list.sortedBy { it.displayTitle.lowercase() }
        store?.saveWorks(_works.value)
    }

    // ---------------- scanning ----------------

    suspend fun rescan(): String? = withContext(Dispatchers.IO) {
        val ctx = appCtx ?: return@withContext "未初始化"
        val sources = _sources.value
        if (sources.isEmpty()) return@withContext null
        _scan.value = ScanState(running = true, message = "正在扫描…", done = 0, total = sources.size)
        val previous = _works.value.associateBy { it.id }
        val newWorks = mutableListOf<Work>()
        val errors = mutableListOf<String>()
        var done = 0
        for (src in sources) {
            _scan.value = ScanState(running = true, message = "扫描 ${src.name}…", done = done, total = sources.size)
            try {
                val found = when {
                    src.isDav -> scanDavSource(src)
                    else -> scanLocalSource(ctx, src)
                }
                for (w in found) {
                    val old = previous[w.id]
                    newWorks.add(
                        if (old != null) w.copy(
                            title = old.title,
                            summary = old.summary,
                            poster = old.poster,
                            backdrop = old.backdrop,
                            year = old.year,
                            score = old.score,
                            bangumiId = old.bangumiId
                        ) else w
                    )
                }
            } catch (e: Throwable) {
                errors.add("${src.name}: ${e.message ?: e.javaClass.simpleName}")
            }
            done++
        }
        _works.value = newWorks.sortedBy { it.displayTitle.lowercase() }
        store?.saveWorks(_works.value)
        _scan.value = ScanState(running = false, message = "", done = done, total = sources.size)
        if (errors.isEmpty()) null else errors.joinToString("；")
    }

    private suspend fun scanDavSource(src: MediaSource): List<Work> {
        val dav = WebDav(src)
        val out = mutableListOf<Work>()
        walkDav(dav, src, src.rootPath.ifBlank { "/" }, out, 0)
        return out
    }

    private suspend fun walkDav(
        dav: WebDav,
        src: MediaSource,
        path: String,
        out: MutableList<Work>,
        depth: Int
    ) {
        if (depth > 4) return
        val entries = try {
            dav.list(path)
        } catch (e: Throwable) {
            if (depth == 0) throw e else return
        }
        val videos = entries.filter { !it.isDir && WebDav.isVideo(it.name) }
        val subs = entries.filter { !it.isDir && WebDav.isSubtitle(it.name) }
        val danmaku = entries.filter { !it.isDir && WebDav.isDanmaku(it.name) }
        if (videos.isNotEmpty()) {
            val folder = if (path == "/") "/" else path.trimEnd('/')
            val title = if (folder == "/") src.name else folder.substringAfterLast('/')
            val eps = videos.sortedBy { episodeNumber(it.name) }.mapIndexed { idx, v ->
                MediaEpisode(
                    id = "${src.id}|${v.path}",
                    sourceId = src.id,
                    path = v.path,
                    name = v.name,
                    size = v.size,
                    number = episodeNumber(v.name).let { if (it > 0) it else idx + 1 },
                    subs = subs.filter { sameBase(it.name, v.name) || subs.size == videos.size }
                        .map { it.path },
                    danmakuFiles = danmaku.filter { sameBase(it.name, v.name) }.map { it.path }
                )
            }
            out.add(
                Work(
                    id = "${src.id}|$folder",
                    sourceId = src.id,
                    folderPath = folder,
                    rawTitle = title,
                    title = cleanTitle(title).ifBlank { title },
                    episodes = eps,
                    scannedAt = System.currentTimeMillis()
                )
            )
        }
        for (d in entries.filter { it.isDir }) {
            if (isJunkFolder(d.name)) continue
            walkDav(dav, src, d.path, out, depth + 1)
        }
    }

    private suspend fun scanLocalSource(ctx: Context, src: MediaSource): List<Work> {
        val root = DocumentFile.fromTreeUri(ctx, Uri.parse(src.treeUri)) ?: return emptyList()
        val byDir = LinkedHashMap<String, Pair<DocumentFile, MutableList<DocumentFile>>>()
        val stack = ArrayDeque<Pair<DocumentFile, Int>>()
        stack.add(root to 0)
        while (stack.isNotEmpty()) {
            val (dir, depth) = stack.removeFirst()
            if (depth > 5) continue
            val children = try { dir.listFiles().toList() } catch (_: Throwable) { emptyList() }
            val videos = children.filter { it.isFile && WebDav.isVideo(it.name ?: "") }
            if (videos.isNotEmpty()) {
                val key = dir.uri.toString()
                val slot = byDir.getOrPut(key) { dir to mutableListOf() }
                slot.second.addAll(videos)
            }
            children.filter { it.isDirectory && !isJunkFolder(it.name ?: "") }
                .forEach { stack.add(it to depth + 1) }
        }
        val out = mutableListOf<Work>()
        for ((key, slot) in byDir) {
            val (dir, videos) = slot
            val children = try { dir.listFiles().toList() } catch (_: Throwable) { emptyList() }
            val subs = children.filter { it.isFile && WebDav.isSubtitle(it.name ?: "") }
            val danmaku = children.filter { it.isFile && WebDav.isDanmaku(it.name ?: "") }
            val title = dir.name ?: src.name
            val eps = videos.sortedBy { episodeNumber(it.name ?: "") }.mapIndexed { idx, f ->
                val n = f.name ?: "video"
                MediaEpisode(
                    id = "${src.id}|${f.uri}",
                    sourceId = src.id,
                    path = f.uri.toString(),
                    name = n,
                    size = f.length(),
                    number = episodeNumber(n).let { if (it > 0) it else idx + 1 },
                    subs = subs.filter { sameBase(it.name ?: "", n) || subs.size == videos.size }
                        .mapNotNull { it.uri.toString() },
                    danmakuFiles = danmaku.filter { sameBase(it.name ?: "", n) }.mapNotNull { it.uri.toString() }
                )
            }
            out.add(
                Work(
                    id = "${src.id}|$key",
                    sourceId = src.id,
                    folderPath = key,
                    rawTitle = title,
                    title = cleanTitle(title).ifBlank { title },
                    episodes = eps,
                    scannedAt = System.currentTimeMillis()
                )
            )
        }
        return out
    }

    // ---------------- metadata ----------------

    suspend fun searchBangumi(keyword: String): List<BgmSubject> {
        val cleaned = cleanTitle(keyword).ifBlank { keyword }
        val first = Bangumi.search(cleaned)
        if (first.isNotEmpty()) return first
        return Bangumi.search(keyword)
    }

    suspend fun applySubject(workId: String, subject: BgmSubject): Work? {
        val work = workById(workId) ?: return null
        val posterFile = File(postersDir(), "poster_${work.id.hashCode().toUInt()}.jpg")
        val ok = Bangumi.downloadPoster(subject.poster, posterFile)
        val preferCn = _settings.value.preferNameCn
        val title = if (preferCn) subject.nameCn.ifBlank { subject.name } else subject.name
        val updated = work.copy(
            title = title.ifBlank { work.title },
            summary = subject.summary.ifBlank { work.summary },
            poster = if (ok) posterFile.absolutePath else work.poster,
            year = subject.date.take(4),
            score = subject.score,
            bangumiId = subject.id
        )
        store?.setOverride(work.id, subject.id)
        overrides[work.id] = subject.id
        refreshWork(updated)
        return updated
    }

    /** 扫描后为缺少海报的条目自动刮削；返回处理条数 */
    suspend fun scrapeMissing(onProgress: (String) -> Unit = {}): Int {
        val s = _settings.value
        if (!s.scrapeEnabled) return 0
        var n = 0
        val targets = _works.value.filter { it.poster.isBlank() && it.bangumiId == 0 }
        for (work in targets) {
            onProgress("刮削 ${work.displayTitle}")
            val override = overrides[work.id]
            val subject = if (override != null) Bangumi.subject(override) else null
            val hit = subject ?: pickBest(work, searchBangumi(work.rawTitle))
            var applied: Work? = null
            if (hit != null) {
                applied = applySubject(work.id, hit)
            }
            if (applied == null || applied.poster.isBlank()) {
                generateThumb(work)
            }
            n++
        }
        return n
    }

    private fun pickBest(work: Work, list: List<BgmSubject>): BgmSubject? {
        if (list.isEmpty()) return null
        val raw = cleanTitle(work.rawTitle).lowercase()
        val best = list.firstOrNull {
            it.nameCn.lowercase().contains(raw) || it.name.lowercase().contains(raw) ||
                raw.contains(it.nameCn.lowercase()) || raw.contains(it.name.lowercase())
        }
        return best ?: list.first()
    }

    /** 没有刮削到海报时，用视频第一集抓帧做封面 */
    suspend fun generateThumb(work: Work): String? {
        val ep = work.episodes.firstOrNull() ?: return null
        val src = _sources.value.firstOrNull { it.id == work.sourceId } ?: return null
        val file = File(postersDir(), "thumb_${work.id.hashCode().toUInt()}.jpg")
        if (file.exists() && file.length() > 2048) {
            refreshWork(work.copy(poster = file.absolutePath))
            return file.absolutePath
        }
        val path = if (src.isDav) {
            val dav = WebDav(src)
            Thumbnails.grab(appCtx!!, dav.playbackUrl(ep.path), dav.headers(), work.id)
        } else {
            Thumbnails.grab(appCtx!!, ep.path, emptyMap(), work.id)
        }
        if (path != null) {
            refreshWork(work.copy(poster = path))
        }
        return path
    }

    // ---------------- playback ----------------

    suspend fun preparePlayback(workId: String, episodeIndex: Int): PlaybackSpec? = withContext(Dispatchers.IO) {
        val work = workById(workId) ?: return@withContext null
        val ep = work.episodes.getOrNull(episodeIndex) ?: return@withContext null
        val src = _sources.value.firstOrNull { it.id == work.sourceId }
        val dav = if (src != null && src.isDav) WebDav(src) else null
        val url = dav?.playbackUrl(ep.path) ?: ep.path
        val headers = dav?.headers() ?: emptyMap()

        val subs = mutableListOf<Pair<String, String>>()
        for (s in ep.subs) {
            val name = s.substringAfterLast('/').substringAfterLast(':')
            val dest = File(subsCacheDir(), name.hashCode().toUInt().toString() + "_" + name)
            val copied = if (dest.exists() && dest.length() > 0) true else runCatching {
                if (dav != null) dav.download(s, dest) else copyUriTo(appCtx!!, s, dest)
            }.getOrDefault(false)
            if (copied && dest.exists()) subs.add(displaySubName(name) to dest.absolutePath)
        }

        val danmakuFiles = mutableListOf<String>()
        for (df in ep.danmakuFiles) {
            val name = df.substringAfterLast('/')
            val dest = File(subsCacheDir(), "dm_" + name.hashCode().toUInt().toString() + "_" + name)
            val copied = if (dest.exists() && dest.length() > 0) true else runCatching {
                if (dav != null) dav.download(df, dest) else copyUriTo(appCtx!!, df, dest)
            }.getOrDefault(false)
            if (copied) danmakuFiles.add(dest.absolutePath)
        }

        val start = progressOf(ep.id)
        PlaybackSpec(
            work = work,
            episode = ep,
            url = url,
            headers = headers,
            subtitles = subs,
            danmakuFiles = danmakuFiles,
            danmakuRemote = emptyList(),
            startPositionMs = if (start > 0) start else 0L
        )
    }

    private fun copyUriTo(ctx: Context, uriString: String, dest: File): Boolean {
        return try {
            val uri = Uri.parse(uriString)
            val input = if (uri.scheme == "file") File(uri.path!!).inputStream() else ctx.contentResolver.openInputStream(uri)
            input?.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
            dest.exists() && dest.length() > 0
        } catch (_: Throwable) {
            false
        }
    }

    fun displaySubName(fileName: String): String {
        val base = fileName.substringBeforeLast('.')
        return base.ifBlank { fileName }
    }

    // ---------------- naming helpers ----------------

    private val bracketPattern = Regex("\\[[^\\]]*\\]|【[^】]*】|\\([^)]*\\)|（[^）]*）")
    private val tagPattern = Regex(
        "(?i)\\b(1080p?|720p?|2160p?|480p?|4k|8k|hevc|avc|av1|x264|x265|h264|h265|aac|flac|ac3|dts|" +
            "web-?dl|webrip|bluray|bdrip|brrip|hdtv|remux|10bit|8bit|hdr|dv|chs|cht|jpn|gb|big5|" +
            "简体|繁体|字幕|合集|全集|完结|连载|内嵌|外挂)\\b"
    )

    fun cleanTitle(raw: String): String {
        var s = raw.replace(bracketPattern, " ")
        s = s.replace(tagPattern, " ")
        s = s.replace(Regex("[_\\-.·]+"), " ")
        s = s.replace(Regex("\\s+"), " ").trim()
        return s
    }

    private val tagWords = Regex(
        "(?i)(1080p?|720p?|2160p?|480p|4k|8k|hevc|avc|av1|x264|x265|h264|h265|aac|flac|" +
            "10bit|8bit|webrip|web-dl|bluray|bdrip|remux|ass|srt|chs|cht|jpn|v2|hdr|dv)"
    )
    private val bracketContent = Regex("\\[[^\\]]*\\]|\\([^)]*\\)|【[^】]*】")

    /** 从文件名解析集数，兼容 " - 01"、"EP05"、"第3集"、"[04]"、"S01E02" 等常见命名 */
    fun episodeNumber(fileName: String): Int {
        val base = fileName.substringBeforeLast('.')

        Regex("(?i)\\bS(\\d{1,2})[ ._-]?E(\\d{1,3})\\b").find(base)?.let {
            it.groupValues[2].toIntOrNull()?.let { n -> if (n in 1..999) return n }
        }
        Regex("第\\s*(\\d{1,4})\\s*[话話集]").find(base)?.let {
            it.groupValues[1].toIntOrNull()?.let { n -> if (n in 1..999) return n }
        }
        // 最常见的 " - 01 [WebRip 1080p ...]" / " - 01v2"
        Regex("\\s[-–—]\\s*(\\d{1,4})(?:v\\d)?(?=\\s|\\[|\\(|$|\\.)").find(base)?.let {
            it.groupValues[1].toIntOrNull()?.let { n -> if (n in 1..999) return n }
        }
        // 独立的方括号集数 [04]
        Regex("\\[\\s*(\\d{1,3})(?:v\\d)?\\s*\\]").find(base)?.let {
            it.groupValues[1].toIntOrNull()?.let { n -> if (n in 1..999) return n }
        }
        Regex("(?i)\\bEP?\\.?\\s?[-_ ]?(\\d{1,4})\\b").find(base)?.let {
            it.groupValues[1].toIntOrNull()?.let { n -> if (n in 1..999) return n }
        }
        // 兜底：去掉发布组/清晰度标签后取最后一个独立数字
        val stripped = bracketContent.replace(base, " ").let { tagWords.replace(it, " ") }
        val candidates = Regex("(?:^|[^0-9])(\\d{1,4})(?:[^0-9]|$)").findAll(stripped)
            .mapNotNull { it.groupValues[1].toIntOrNull() }
            .filter { it in 1..999 && it !in setOf(264, 265, 480, 720, 1080, 2160) }
            .toList()
        return candidates.lastOrNull() ?: 0
    }

    fun sameBase(subName: String, videoName: String): Boolean {
        val sb = subName.substringBeforeLast('.').lowercase()
        val vb = videoName.substringBeforeLast('.').lowercase()
        return sb == vb || vb.startsWith(sb) || sb.startsWith(vb)
    }
}
