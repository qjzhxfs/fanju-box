package app.fanju.box.data

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * 封面兜底：没有刮削到海报时，用视频帧当封面（MediaMetadataRetriever，不需要 ffmpeg）。
 */
object Thumbnails {

    suspend fun grab(
        ctx: Context,
        url: String,
        headers: Map<String, String>,
        cacheKey: String,
        atMs: Long = 5_000L
    ): String? = withContext(Dispatchers.IO) {
        val dir = File(ctx.cacheDir, "thumbs").apply { mkdirs() }
        val dest = File(dir, cacheKey.hashCode().toUInt().toString(16) + ".jpg")
        if (dest.exists() && dest.length() > 2048) return@withContext dest.absolutePath
        val r = MediaMetadataRetriever()
        try {
            if (url.startsWith("http")) {
                r.setDataSource(url, headers)
            } else {
                r.setDataSource(ctx, Uri.parse(url))
            }
            val frame: Bitmap? = r.getFrameAtTime(atMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: r.frameAtTime
            if (frame != null) {
                val scaled = scale(frame, 480)
                dest.outputStream().use { out -> scaled.compress(Bitmap.CompressFormat.JPEG, 82, out) }
                dest.absolutePath
            } else null
        } catch (_: Throwable) {
            null
        } finally {
            try { r.release() } catch (_: Throwable) {}
        }
    }

    suspend fun durationMs(ctx: Context, url: String, headers: Map<String, String>): Long =
        withContext(Dispatchers.IO) {
            val r = MediaMetadataRetriever()
            try {
                if (url.startsWith("http")) r.setDataSource(url, headers)
                else r.setDataSource(ctx, Uri.parse(url))
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            } catch (_: Throwable) {
                0L
            } finally {
                try { r.release() } catch (_: Throwable) {}
            }
        }

    private fun scale(bmp: Bitmap, targetW: Int): Bitmap {
        if (bmp.width <= targetW) return bmp
        val h = (bmp.height.toFloat() * targetW / bmp.width).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bmp, targetW, h, true)
    }
}
