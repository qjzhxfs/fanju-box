package app.fanju.box.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import app.fanju.box.data.MediaSource
import app.fanju.box.data.Repo
import app.fanju.box.data.WebDav
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

@Composable
fun AddSourceDialog(onDismiss: () -> Unit, onSaved: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var rootPath by remember { mutableStateOf("/") }
    var testing by remember { mutableStateOf(false) }
    var testResult by remember { mutableStateOf<String?>(null) }

    val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Throwable) {
            }
            val doc = DocumentFile.fromTreeUri(ctx, uri)
            val src = MediaSource(
                id = UUID.randomUUID().toString().take(8),
                type = "local",
                name = doc?.name?.takeIf { it.isNotBlank() } ?: "本地文件夹",
                treeUri = uri.toString()
            )
            Repo.addSource(src)
            onSaved()
            onDismiss()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("添加媒体源") },
        text = {
            Column {
                TabRow(selectedTabIndex = tab, containerColor = MaterialTheme.colorScheme.surface) {
                    Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("WebDAV") })
                    Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("本地文件夹") })
                }
                Spacer(Modifier.height(12.dp))
                if (tab == 0) {
                    PasteField(
                        value = url, onValueChange = { url = it },
                        label = "WebDAV 地址，例如 https://nas:5006/dav",
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    PasteField(
                        value = user, onValueChange = { user = it },
                        label = "用户名（可留空）",
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    PasteField(
                        value = pass, onValueChange = { pass = it },
                        label = "密码（可留空）",
                        password = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    PasteField(
                        value = rootPath, onValueChange = { rootPath = it },
                        label = "根目录（例如 /番剧，默认 /）",
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = name, onValueChange = { name = it },
                        label = { Text("显示名称（可留空）") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(enabled = !testing, onClick = {
                            testing = true
                            testResult = null
                            val src = MediaSource(
                                id = "test", type = "webdav",
                                name = name.ifBlank { "WebDAV" },
                                baseUrl = url, user = user, pass = pass, rootPath = rootPath.ifBlank { "/" }
                            )
                            scope.launch {
                                testResult = withContext(Dispatchers.IO) {
                                    try {
                                        val list = WebDav(src).list(rootPath.ifBlank { "/" })
                                        "连接成功，发现 ${list.size} 项"
                                    } catch (e: Throwable) {
                                        "连接失败：${e.message ?: e.javaClass.simpleName}"
                                    }
                                }
                                testing = false
                            }
                        }) { Text(if (testing) "测试中…" else "测试连接") }
                        if (testing) CircularProgressIndicator(modifier = Modifier.height(16.dp), strokeWidth = 2.dp)
                    }
                    testResult?.let {
                        Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    Text(
                        "选择一个存放番剧的文件夹。App 只会读取你选中的目录，扫描其中的视频文件。",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { pickFolder.launch(null) }, modifier = Modifier.fillMaxWidth()) {
                        Text("选择文件夹")
                    }
                }
            }
        },
        confirmButton = {
            if (tab == 0) {
                TextButton(onClick = {
                    if (url.isBlank()) {
                        testResult = "请填写 WebDAV 地址"
                        return@TextButton
                    }
                    val src = MediaSource(
                        id = UUID.randomUUID().toString().take(8),
                        type = "webdav",
                        name = name.ifBlank { "WebDAV" },
                        baseUrl = url.trim(),
                        user = user,
                        pass = pass,
                        rootPath = rootPath.ifBlank { "/" }
                    )
                    Repo.addSource(src)
                    onSaved()
                    onDismiss()
                }) { Text("保存") }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } }
    )
}

@Composable
fun SourceRow(
    source: MediaSource,
    onRemove: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(source.name, fontSize = 14.sp)
            Text(
                if (source.isDav) source.baseUrl + (source.rootPath.ifBlank { "" })
                else Uri.decode(source.treeUri),
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
        TextButton(onClick = onRemove) { Text("移除") }
    }
}

@Composable
fun RowSpacer(height: Int) {
    Spacer(Modifier.height(height.dp))
}

@Composable
fun EmptyHint(title: String, subtitle: String, modifier: Modifier = Modifier, action: (@Composable () -> Unit)? = null) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
            Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            action?.invoke()
        }
    }
}

@Composable
fun ClickRow(text: String, onClick: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable { onClick() }
            .padding(14.dp)
    ) { Text(text, fontSize = 14.sp) }
}


/** 带「粘贴」按钮的输入框：手机上手输 WebDAV 地址/密码容易出错，直接从剪贴板取。 */
@Composable
fun PasteField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    singleLine: Boolean = true,
    password: Boolean = false,
    modifier: Modifier = Modifier
) {
    val clip = LocalClipboardManager.current
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        singleLine = singleLine,
        visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        keyboardOptions = if (password) KeyboardOptions(keyboardType = KeyboardType.Password) else KeyboardOptions.Default,
        trailingIcon = {
            androidx.compose.material3.IconButton(onClick = {
                val text = clip.getText()?.text
                if (!text.isNullOrBlank()) onValueChange(text.trim())
            }) {
                Icon(Icons.Default.ContentPaste, contentDescription = "粘贴")
            }
        },
        modifier = modifier
    )
}
