package app.fanju.box

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import app.fanju.box.data.Repo
import app.fanju.box.ui.DetailScreen
import app.fanju.box.ui.FanjuTheme
import app.fanju.box.ui.HomeScreen
import app.fanju.box.ui.PlayerScreen
import app.fanju.box.ui.SettingsScreen
import app.fanju.box.ui.Bg

sealed interface Screen {
    data object Home : Screen
    data class Detail(val workId: String) : Screen
    data class Player(val workId: String, val index: Int) : Screen
    data object Settings : Screen
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Repo.init(applicationContext)
        enableEdgeToEdge()
        setContent {
            FanjuTheme {
                Surface(modifier = Modifier.fillMaxSize().background(Bg)) {
                    AppRoot()
                }
            }
        }
    }
}

@Composable
private fun AppRoot() {
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    BackHandler(enabled = screen != Screen.Home) {
        screen = when (val s = screen) {
            is Screen.Player -> Screen.Detail(s.workId)
            else -> Screen.Home
        }
    }
    when (val s = screen) {
        Screen.Home -> HomeScreen(
            onOpenWork = { screen = Screen.Detail(it) },
            onOpenSettings = { screen = Screen.Settings }
        )
        is Screen.Detail -> DetailScreen(
            workId = s.workId,
            onBack = { screen = Screen.Home },
            onPlay = { index -> screen = Screen.Player(s.workId, index) }
        )
        is Screen.Player -> PlayerScreen(
            workId = s.workId,
            startIndex = s.index,
            onBack = { screen = Screen.Detail(s.workId) }
        )
        Screen.Settings -> SettingsScreen(onBack = { screen = Screen.Home })
    }
}
