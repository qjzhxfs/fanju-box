package app.fanju.box.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.media.AudioManager
import android.net.Uri
import android.util.Log
import android.view.SurfaceView
import android.view.HapticFeedbackConstants
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.text.CueGroup
import androidx.media3.ui.AspectRatioFrameLayout
import app.fanju.box.data.Dandanplay
import app.fanju.box.data.PlaybackSpec
import app.fanju.box.data.Repo
import app.fanju.box.player.DanmakuItem
import app.fanju.box.player.DanmakuLayout
import app.fanju.box.player.DanmakuParser
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job
import okhttp3.OkHttpClient
import java.io.File
import java.util.concurrent.TimeUnit
import kotlin.math.abs

private const val SPEED_STEP = 0.0f

@Composable
fun PlayerScreen(workId: String, startIndex: Int, onBack: () -> Unit) {
    val works by Repo.works.collectAsState()
    val work = works.firstOrNull { it.id == workId }
    var index by remember { mutableIntStateOf(startIndex) }
    var spec by remember { mutableStateOf<PlaybackSpec?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(workId, index) {
        spec = null
        error = null
        val s = Repo.preparePlayback(workId, index)
        if (s == null) error = "无法读取这一集，检查网络或媒体源设置" else spec = s
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        val s = spec
        if (s != null) {
            PlayerContent(
                spec = s,
                episodeIndex = index,
                episodeCount = work?.episodeCount ?: 0,
                onBack = onBack,
                onNext = { if (work != null && index < work.episodeCount - 1) index++ },
                onPrev = { if (index > 0) index-- }
            )
        } else if (error != null) {
            Column(
                Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(error!!, color = Color.White, fontSize = 14.sp)
                Spacer(Modifier.height(12.dp))
                TextButton(onClick = onBack) { Text("返回") }
            }
        } else {
            CircularProgressIndicator(color = Gold, modifier = Modifier.align(Alignment.Center))
        }
    }
}

@Composable
private fun PlayerContent(
    spec: PlaybackSpec,
    episodeIndex: Int,
    episodeCount: Int,
    onBack: () -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit
) {
    val ctx = LocalContext.current
    val activity = remember(ctx) { ctx.findActivity() }
    val density = LocalDensity.current.density
    val settings by Repo.settings.collectAsState()

    val player = remember(spec.url) { buildPlayer(ctx, spec) }
    val view = LocalView.current
    DisposableEffect(Unit) {
        val window = activity?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, view) }
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose { controller?.show(WindowInsetsCompat.Type.systemBars()) }
    }
    val surfaceView = remember(player) {
        SurfaceView(ctx).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
    }
    val aspectContainer = remember(player) {
        AspectRatioFrameLayout(ctx).apply {
            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
            addView(
                surfaceView,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
        }
    }

    var isPlaying by remember { mutableStateOf(false) }
    var buffering by remember { mutableStateOf(true) }
    var positionMs by remember { mutableLongStateOf(spec.startPositionMs) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var controlsVisible by remember { mutableStateOf(true) }
    var speedIdx by remember { mutableIntStateOf(0) }
    var boost by remember { mutableStateOf(false) }
    var cueText by remember { mutableStateOf("") }
    var subtitleOff by remember { mutableStateOf(false) }
    var danmakuOn by remember { mutableStateOf(settings.danmakuEnabled) }
    var danmakuItems by remember { mutableStateOf<List<DanmakuItem>>(emptyList()) }
    var seekPreview by remember { mutableStateOf<Long?>(null) }
    var gestureHint by remember { mutableStateOf<String?>(null) }
    var showSubMenu by remember { mutableStateOf(false) }
    var locked by remember { mutableStateOf(false) }
    var videoAspect by remember { mutableFloatStateOf(0f) }
    var gestureMode by remember { mutableIntStateOf(0) }
    val gestureScope = rememberCoroutineScope()

    LaunchedEffect(videoAspect) {
        if (videoAspect > 0f) aspectContainer.setAspectRatio(videoAspect)
    }

    // 播放器监听
    DisposableEffect(player) {
        player.setVideoSurfaceView(surfaceView)
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING
            }

            override fun onVideoSizeChanged(size: VideoSize) {
                if (size.height > 0 && size.width > 0) {
                    videoAspect = size.width * size.pixelWidthHeightRatio / size.height
                } else if (size.width > 0 && size.height > 0) {
                    videoAspect = size.width.toFloat() / size.height
                }
            }

            override fun onCues(cueGroup: CueGroup) {
                cueText = cueGroup.cues.joinToString("\n") { it.text?.toString().orEmpty() }.trim()
            }
        }
        player.addListener(listener)
        onDispose {
            Repo.setProgress(spec.episode.id, player.currentPosition.coerceAtLeast(0))
            player.removeListener(listener)
            player.release()
        }
    }

    // 进度轮询
    LaunchedEffect(player) {
        while (true) {
            positionMs = player.currentPosition.coerceAtLeast(0)
            durationMs = player.duration.coerceAtLeast(0)
            delay(250)
        }
    }

    // 定时保存进度
    LaunchedEffect(player) {
        while (true) {
            delay(5000)
            val pos = player.currentPosition
            if (pos > 1000) Repo.setProgress(spec.episode.id, pos)
        }
    }

    // 控制栏自动隐藏
    LaunchedEffect(controlsVisible, isPlaying, locked) {
        if (controlsVisible && isPlaying && !locked) {
            delay(4000)
            controlsVisible = false
        }
    }

    // 弹幕装载
    LaunchedEffect(spec) {
        val local = spec.danmakuFiles.flatMap { runCatching { DanmakuParser.parseFile(File(it)) }.getOrDefault(emptyList()) }
        if (local.isNotEmpty()) {
            danmakuItems = local
            return@LaunchedEffect
        }
        if (settings.danmakuAppId.isNotBlank() && settings.danmakuAppSecret.isNotBlank()) {
            val hits = Dandanplay.search(settings, Repo.cleanTitle(spec.work.rawTitle))
            if (hits.isNotEmpty()) {
                val num = spec.episode.number
                val hit = hits.firstOrNull { it.episodeTitle.contains(num.toString()) } ?: hits.getOrNull(num - 1)
                if (hit != null) danmakuItems = Dandanplay.comment(settings, hit.episodeId)
            }
        }
    }

    fun speedValue(): Float = if (boost) 3f else listOf(1f, 1.25f, 1.5f, 2f, 3f)[speedIdx]

    fun applySpeed() {
        player.setPlaybackSpeed(speedValue())
    }

    fun seekBy(ms: Long) {
        val target = (player.currentPosition + ms).coerceIn(0, durationMs.coerceAtLeast(0))
        player.seekTo(target)
        positionMs = target
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(locked) {
                if (locked) return@pointerInput
                try {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val startX = down.position.x
                    val startY = down.position.y
                    val width = size.width.toFloat()
                    var mode = 0 // 0 tap, 1 seek, 2 volume, 3 brightness, 4 speed
                    gestureMode = 0
                    // 手指按住不动时系统不会继续派发 move 事件，所以用定时任务判定长按
                    var longPressJob: Job? = gestureScope.launch {
                        delay(300)
                        if (gestureMode == 0) {
                            gestureMode = 4
                            boost = true
                            applySpeed()
                            controlsVisible = false
                            gestureHint = null
                            view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                            Log.i("fanju-gesture", "speed boost on (3x)")
                        }
                    }
                    var lastPos = down.position
                    var seekTarget = positionMs
                    var holdStart = System.currentTimeMillis()
                    while (true) {
                        val ev = awaitPointerEvent()
                        val ch = ev.changes.firstOrNull() ?: break
                        val dt = System.currentTimeMillis() - holdStart
                        if (ch.pressed) {
                            val dx = ch.position.x - startX
                            val dy = ch.position.y - startY
                            if (mode == 0 && (abs(dx) > 30f || abs(dy) > 30f)) {
                                mode = if (abs(dx) > abs(dy)) 1
                                else if (startX < width / 2) 3 else 2
                                gestureMode = mode
                                longPressJob?.cancel()
                                Log.i("fanju-gesture", when (mode) {
                                    1 -> "horizontal seek gesture"
                                    2 -> "vertical volume gesture"
                                    else -> "vertical brightness gesture"
                                })
                                if (mode == 3) gestureHint = "亮度 ${(currentBrightness(activity) * 100).toInt()}%"
                                if (mode == 2) gestureHint = "音量"
                            }
                            when (mode) {
                                1 -> {
                                    val seekRange = (durationMs * 0.08f).coerceIn(60_000f, 600_000f)
                                    val deltaMs = (dx / width * seekRange).toLong()
                                    seekTarget = (positionMs + deltaMs).coerceIn(0, durationMs.coerceAtLeast(0))
                                    seekPreview = seekTarget
                                    gestureHint = "${fmt(seekTarget)} / ${fmt(durationMs)}"
                                }
                                2 -> {
                                    val dy2 = (ch.position.y - lastPos.y) / size.height.toFloat()
                                    adjustVolume(ctx, -dy2)
                                    gestureHint = "音量 ${(currentVolumeRatio(ctx) * 100).toInt()}%"
                                }
                                3 -> {
                                    val dy2 = (ch.position.y - lastPos.y) / size.height.toFloat()
                                    val nb = (currentBrightness(activity) - dy2).coerceIn(0.02f, 1f)
                                    setBrightness(activity, nb)
                                    gestureHint = "亮度 ${(nb * 100).toInt()}%"
                                }
                            }
                            lastPos = ch.position
                        } else {
                            val dtRelease = System.currentTimeMillis() - holdStart
                            longPressJob?.cancel()
                            if (boost) {
                                boost = false
                                applySpeed()
                                gestureHint = null
                                Log.i("fanju-gesture", "speed boost off")
                            }
                            if (mode == 2 || mode == 3) Log.i("fanju-gesture", if (mode == 2) "volume gesture released" else "brightness gesture released")
                            when (mode) {
                                1 -> {
                                    player.seekTo(seekTarget)
                                    positionMs = seekTarget
                                    seekPreview = null
                                    Log.i("fanju-gesture", "seek commit -> ${seekTarget}ms")
                                }
                                4 -> Unit
                                0 -> {
                                    if (dtRelease < 350) {
                                        if (controlsVisible) controlsVisible = false else controlsVisible = true
                                    }
                                }
                            }
                            gestureHint = null
                            break
                        }
                    }
                }
                } finally {
                    // 手势被系统取消时也要把临时倍速还原，避免一直 3x 播到结尾
                    if (boost) {
                        boost = false
                        applySpeed()
                    }
                }
            }
    ) {
        AndroidView(factory = { aspectContainer }, modifier = Modifier.fillMaxSize())

        // 弹幕
        DanmakuLayer(
            items = danmakuItems,
            enabled = danmakuOn && danmakuItems.isNotEmpty(),
            playing = isPlaying,
            positionProvider = { player.currentPosition },
            modifier = Modifier.fillMaxSize()
        )

        // 字幕
        if (cueText.isNotBlank() && !subtitleOff) {
            Text(
                cueText,
                color = Color.White,
                fontSize = 16.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 70.dp, start = 24.dp, end = 24.dp)
            )
        }

        if (buffering && !locked) {
            CircularProgressIndicator(color = Gold, modifier = Modifier.align(Alignment.Center))
        }

        seekPreview?.let {
            Text(
                fmt(it),
                color = Gold,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 60.dp)
                    .background(Color(0x99000000), RoundedCornerShape(8.dp))
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            )
        }

        gestureHint?.let {
            Text(
                it,
                color = Color.White,
                fontSize = 13.sp,
                modifier = Modifier
                    .align(Alignment.Center)
                    .background(Color(0x99000000), RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }

        if (controlsVisible && !locked) {
            // 顶部
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(Color(0x66000000))
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回", tint = Color.White)
                }
                Column(Modifier.weight(1f)) {
                    Text(
                        spec.work.displayTitle,
                        color = Color.White,
                        fontSize = 14.sp,
                        maxLines = 1
                    )
                    Text(
                        spec.episode.name,
                        color = Color(0xFFBBBBC4),
                        fontSize = 11.sp,
                        maxLines = 1
                    )
                }
                TextButton(onClick = { danmakuOn = !danmakuOn }) {
                    Text(if (danmakuOn) "弹幕开" else "弹幕关", color = if (danmakuOn) Gold else Color.White, fontSize = 12.sp)
                }
                IconButton(onClick = { locked = true; controlsVisible = false }) {
                    Icon(Icons.Default.LockOpen, contentDescription = "锁定", tint = Color.White)
                }
            }

            // 底部控制
            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(Color(0x88000000))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(fmt(positionMs), color = Color.White, fontSize = 11.sp)
                    Slider(
                        value = positionMs.toFloat(),
                        onValueChange = {
                            positionMs = it.toLong()
                            player.seekTo(it.toLong())
                        },
                        valueRange = 0f..(durationMs.coerceAtLeast(1)).toFloat(),
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 8.dp),
                        colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold)
                    )
                    Text(fmt(durationMs), color = Color.White, fontSize = 11.sp)
                }
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    IconButton(onClick = onPrev, enabled = episodeIndex > 0) {
                        Icon(Icons.Default.SkipPrevious, contentDescription = "上一集", tint = Color.White)
                    }
                    IconButton(onClick = { seekBy(-10_000) }) {
                        Icon(Icons.Default.FastRewind, contentDescription = "后退10秒", tint = Color.White)
                    }
                    IconButton(onClick = {
                        if (player.isPlaying) player.pause() else player.play()
                    }) {
                        Icon(
                            if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "播放暂停",
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                    IconButton(onClick = { seekBy(10_000) }) {
                        Icon(Icons.Default.FastForward, contentDescription = "前进10秒", tint = Color.White)
                    }
                    IconButton(onClick = onNext, enabled = episodeIndex < episodeCount - 1) {
                        Icon(Icons.Default.SkipNext, contentDescription = "下一集", tint = Color.White)
                    }
                    TextButton(onClick = {
                        speedIdx = (speedIdx + 1) % 5
                        applySpeed()
                    }) {
                        Text(
                            if (boost) "3.0x（长按）" else "${listOf(1f, 1.25f, 1.5f, 2f, 3f)[speedIdx]}x",
                            color = if (boost) Gold else Color.White,
                            fontSize = 12.sp
                        )
                    }
                    Box {
                        IconButton(onClick = { showSubMenu = true }) {
                            Icon(Icons.Default.ClosedCaption, contentDescription = "字幕", tint = Color.White)
                        }
                        DropdownMenu(expanded = showSubMenu, onDismissRequest = { showSubMenu = false }) {
                            DropdownMenuItem(text = { Text("关闭字幕") }, onClick = {
                                subtitleOff = true
                                cueText = ""
                                val params = player.trackSelectionParameters.buildUpon()
                                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
                                player.trackSelectionParameters = params
                                showSubMenu = false
                            })
                            spec.subtitles.forEachIndexed { i, pair ->
                                DropdownMenuItem(text = { Text(pair.first) }, onClick = {
                                    subtitleOff = false
                                    enableSubtitle(player, i)
                                    showSubMenu = false
                                })
                            }
                        }
                    }
                }
            }
        }

        if (locked) {
            Box(
                Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectTapGestures(onTap = {
                            locked = false
                            controlsVisible = true
                        })
                    }
            )
            Row(
                Modifier
                    .align(Alignment.CenterStart)
                    .padding(16.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0x66000000))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Lock, contentDescription = "已锁定", tint = Color.White)
                Spacer(Modifier.width(6.dp))
                Text("点击解锁", color = Color.White, fontSize = 11.sp)
            }
        }

        // 3x 快进提示
        if (boost) {
            Text(
                "3x 快进中",
                color = Gold,
                fontSize = 12.sp,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 90.dp)
                    .background(Color(0x99000000), RoundedCornerShape(6.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
private fun DanmakuLayer(
    items: List<DanmakuItem>,
    enabled: Boolean,
    playing: Boolean,
    positionProvider: () -> Long,
    modifier: Modifier = Modifier
) {
    if (!enabled) return
    val density = LocalDensity.current.density
    val layout = remember(items, density) { DanmakuLayout(items, 6, density) }
    val measurer = rememberTextMeasurer()
    var frame by remember { mutableLongStateOf(0L) }

    LaunchedEffect(playing) {
        while (playing) {
            withFrameNanos { frame = it }
        }
    }

    androidx.compose.foundation.Canvas(modifier = modifier) {
        frame
        val pos = positionProvider()
        val active = layout.activeAt(pos)
        if (active.isEmpty()) return@Canvas
        val laneHeight = size.height * 0.55f / layout.lanes
        for (p in active) {
            val span = (p.leaveMs - p.enterMs).coerceAtLeast(1)
            val progress = (pos - p.enterMs).toFloat() / span.toFloat()
            val style = TextStyle(fontSize = p.item.sizeSp.sp, color = Color(0xFF000000 or p.item.color.toLong()))
            val measured = measurer.measure(AnnotatedString(p.item.text), style = style)
            val x = size.width - progress * (size.width + measured.size.width)
            val y = 10f + p.lane * laneHeight
            drawText(measured, topLeft = Offset(x, y))
        }
    }
}

private fun enableSubtitle(player: ExoPlayer, index: Int) {
    val params = player.trackSelectionParameters.buildUpon()
        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
        .build()
    player.trackSelectionParameters = params
    val textGroups = player.currentTracks.groups.filter { it.type == C.TRACK_TYPE_TEXT }
    val group = textGroups.getOrNull(index) ?: return
    val override = TrackSelectionOverride(group.mediaTrackGroup, 0)
    player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
        .setOverrideForType(override)
        .build()
}

private fun buildPlayer(ctx: Context, spec: PlaybackSpec): ExoPlayer {
    val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()
    val okFactory = OkHttpDataSource.Factory(http)
    if (spec.headers.isNotEmpty()) okFactory.setDefaultRequestProperties(spec.headers)
    val dsFactory = DefaultDataSource.Factory(ctx, okFactory)
    val player = ExoPlayer.Builder(ctx)
        .setMediaSourceFactory(DefaultMediaSourceFactory(dsFactory))
        .setSeekBackIncrementMs(10_000)
        .setSeekForwardIncrementMs(10_000)
        .build()

    val subs = spec.subtitles.mapIndexed { i, pair ->
        MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(File(pair.second)))
            .setMimeType(subMime(pair.second))
            .setLanguage("zh")
            .setLabel(pair.first)
            .setSelectionFlags(if (i == 0) C.SELECTION_FLAG_DEFAULT else 0)
            .build()
    }
    val item = MediaItem.Builder()
        .setUri(Uri.parse(spec.url))
        .setSubtitleConfigurations(subs)
        .build()
    player.setMediaItem(item)
    if (spec.startPositionMs > 1000) player.seekTo(spec.startPositionMs)
    player.playWhenReady = true
    player.prepare()
    return player
}

private fun subMime(path: String): String = when (path.substringAfterLast('.').lowercase()) {
    "srt" -> MimeTypes.APPLICATION_SUBRIP
    "ass", "ssa" -> MimeTypes.TEXT_SSA
    "vtt" -> MimeTypes.TEXT_VTT
    "ttml" -> MimeTypes.APPLICATION_TTML
    else -> MimeTypes.APPLICATION_SUBRIP
}

private fun fmt(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}

private fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c != null) {
        if (c is Activity) return c
        c = (c as? ContextWrapper)?.baseContext
    }
    return null
}

private fun currentBrightness(activity: Activity?): Float {
    val v = activity?.window?.attributes?.screenBrightness ?: -1f
    return if (v < 0f) 0.5f else v
}

private fun setBrightness(activity: Activity?, value: Float) {
    val w = activity?.window ?: return
    val attrs = w.attributes
    attrs.screenBrightness = value.coerceIn(0.02f, 1f)
    w.attributes = attrs
}

private fun currentVolumeRatio(ctx: Context): Float {
    val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
    return am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
}

private fun adjustVolume(ctx: Context, deltaRatio: Float) {
    val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
    val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
    val target = (cur - deltaRatio * max).toInt().coerceIn(0, max)
    am.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
}
