package app.fanju.box.ui

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.io.File

/** 封面模型：本地绝对路径、content:// 与 http(s) 都能交给 Coil */
fun posterModel(poster: String): Any? = when {
    poster.isBlank() -> null
    poster.startsWith("http") -> poster
    poster.startsWith("content:") -> Uri.parse(poster)
    poster.startsWith("file:") -> Uri.parse(poster)
    else -> File(poster)
}

@Composable
fun PosterImage(
    poster: String,
    modifier: Modifier = Modifier,
    label: String = "",
    contentScale: ContentScale = ContentScale.Crop
) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        modifier = modifier.clip(shape).background(CardBg2),
        contentAlignment = Alignment.Center
    ) {
        if (poster.isBlank()) {
            Text(
                text = label.take(1),
                color = TextDim,
                fontSize = 28.sp,
                textAlign = TextAlign.Center
            )
        } else {
            AsyncImage(
                model = posterModel(poster),
                contentDescription = label,
                contentScale = contentScale,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable
fun DimSurface(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(modifier = modifier.background(MaterialTheme.colorScheme.surface)) { content() }
}
