package app.fanju.box.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Store(private val ctx: Context) {
    private val dir: File = File(ctx.filesDir, "library").apply { mkdirs() }

    private fun file(name: String) = File(dir, name)

    private fun readJson(name: String): JSONObject? = try {
        val f = file(name)
        if (f.exists()) JSONObject(f.readText()) else null
    } catch (_: Throwable) {
        null
    }

    private fun writeJson(name: String, obj: Any) {
        try {
            file(name).writeText(obj.toString())
        } catch (_: Throwable) {
        }
    }

    // ---- sources ----
    fun loadSources(): List<MediaSource> {
        val arr = readJson("sources.json")?.optJSONArray("sources") ?: return emptyList()
        val out = mutableListOf<MediaSource>()
        for (i in 0 until arr.length()) out.add(MediaSource.fromJson(arr.getJSONObject(i)))
        return out
    }

    fun saveSources(list: List<MediaSource>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        writeJson("sources.json", JSONObject().put("sources", arr))
    }

    // ---- works ----
    fun loadWorks(): List<Work> {
        val arr = readJson("works.json")?.optJSONArray("works") ?: return emptyList()
        val out = mutableListOf<Work>()
        for (i in 0 until arr.length()) out.add(Work.fromJson(arr.getJSONObject(i)))
        return out
    }

    fun saveWorks(list: List<Work>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        writeJson("works.json", JSONObject().put("works", arr))
    }

    // ---- manually chosen scrape result (user picked a Bangumi subject) ----
    fun loadOverrides(): Map<String, Int> {
        val obj = readJson("overrides.json") ?: return emptyMap()
        val out = mutableMapOf<String, Int>()
        obj.keys().forEach { key ->
            val v = obj.optInt(key)
            if (v > 0) out[key] = v
        }
        return out
    }

    fun setOverride(workId: String, subjectId: Int) {
        val obj = readJson("overrides.json") ?: JSONObject()
        obj.put(workId, subjectId)
        writeJson("overrides.json", obj)
    }

    fun clearOverride(workId: String) {
        val obj = readJson("overrides.json") ?: return
        obj.remove(workId)
        writeJson("overrides.json", obj)
    }

    // ---- playback progress ----
    fun loadProgress(): MutableMap<String, Long> {
        val obj = readJson("progress.json") ?: return mutableMapOf()
        val out = mutableMapOf<String, Long>()
        obj.keys().forEach { k -> out[k] = obj.optLong(k) }
        return out
    }

    fun saveProgress(map: Map<String, Long>) {
        val obj = JSONObject()
        map.forEach { (k, v) -> obj.put(k, v) }
        writeJson("progress.json", obj)
    }

    // ---- settings ----
    fun loadSettings(): AppSettings = readJson("settings.json")?.let { AppSettings.fromJson(it) } ?: AppSettings()

    fun saveSettings(s: AppSettings) = writeJson("settings.json", s.toJson())
}
