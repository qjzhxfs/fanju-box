package app.fanju.box.data

import android.util.Xml
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Credentials
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.HttpUrl.Companion.toHttpUrl
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.StringReader
import java.util.concurrent.TimeUnit

/**
 * 最小可用的 WebDAV 客户端：PROPFIND 列目录、GET 读文件。
 * 兼容 Alist / OpenList、群晖、Nextcloud / ownCloud、坚果云等标准 WebDAV 服务。
 */
class WebDav(val source: MediaSource) {

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    private val baseUrl = source.baseUrl.trim().trimEnd('/').let { if (it.startsWith("http")) it else "https://$it" }

    private fun baseHttpUrl() = (baseUrl + "/").toHttpUrl()

    fun authHeader(): String? =
        if (source.user.isNotBlank() || source.pass.isNotBlank()) Credentials.basic(source.user, source.pass) else null

    fun headers(): Map<String, String> {
        val h = mutableMapOf("User-Agent" to UA)
        authHeader()?.let { h["Authorization"] = it }
        return h
    }

    fun uriFor(path: String) = buildUrl(path)

    private fun buildUrl(path: String) = baseHttpUrl().newBuilder().apply {
        val rel = path.trim('/')
        if (rel.isNotEmpty()) addPathSegments(rel)
    }.build()

    fun playbackUrl(path: String): String = buildUrl(path).toString()

    /** 列目录，path 为相对 WebDAV 根的路径，根用 "/" */
    suspend fun list(path: String): List<DavEntry> = withContext(Dispatchers.IO) {
        val body = """<?xml version="1.0" encoding="utf-8"?>
<d:propfind xmlns:d="DAV:"><d:prop>
<d:displayname/><d:resourcetype/><d:getcontentlength/><d:getlastmodified/><d:getcontenttype/>
</d:prop></d:propfind>"""
        val url = buildUrl(ensureDir(path))
        val req = Request.Builder()
            .url(url)
            .method("PROPFIND", body.toRequestBody("application/xml; charset=utf-8".toMediaType()))
            .header("Depth", "1")
            .header("User-Agent", UA)
            .apply { authHeader()?.let { header("Authorization", it) } }
            .build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) {
                throw WebDavException("服务器返回 ${resp.code} ${resp.message}（${url}）")
            }
            val text = resp.body?.string().orEmpty()
            val entries = parseMultiStatus(text)
            // 去掉自身
            entries.filter { it.path.trimEnd('/') != path.trimEnd('/') && it.path.trimEnd('/').isNotEmpty() }
                .sortedWith(compareByDescending<DavEntry> { it.isDir }.thenBy { it.name.lowercase() })
        }
    }

    private fun ensureDir(path: String): String {
        val p = path.trim()
        return if (p.isEmpty() || p == "/") "/" else p.trimEnd('/') + "/"
    }

    suspend fun readText(path: String, maxBytes: Int = 2 * 1024 * 1024): String? = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url(buildUrl(path)).get()
                .header("User-Agent", UA)
                .apply { authHeader()?.let { header("Authorization", it) } }
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext null
                resp.body?.byteStream()?.let { stream ->
                    val buf = ByteArrayOutputStream()
                    val tmp = ByteArray(16 * 1024)
                    var total = 0
                    while (true) {
                        val n = stream.read(tmp)
                        if (n <= 0 || total >= maxBytes) break
                        buf.write(tmp, 0, n)
                        total += n
                    }
                    String(buf.toByteArray(), Charsets.UTF_8)
                }
            }
        } catch (_: Throwable) {
            null
        }
    }

    suspend fun download(path: String, dest: File): Boolean = withContext(Dispatchers.IO) {
        try {
            dest.parentFile?.mkdirs()
            val req = Request.Builder().url(buildUrl(path)).get()
                .header("User-Agent", UA)
                .apply { authHeader()?.let { header("Authorization", it) } }
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext false
                val body = resp.body ?: return@withContext false
                dest.outputStream().use { out -> body.byteStream().copyTo(out) }
            }
            true
        } catch (_: Throwable) {
            false
        }
    }

    private fun parseMultiStatus(text: String): List<DavEntry> {
        val out = mutableListOf<DavEntry>()
        try {
            val parser = Xml.newPullParser()
            parser.setInput(StringReader(text))
            var event = parser.eventType
            var cur: MutableMap<String, String>? = null
            var curIsDir = false
            val seenProps = HashSet<String>()
            while (event != XmlPullParser.END_DOCUMENT) {
                when (event) {
                    XmlPullParser.START_TAG -> {
                        val name = parser.name.lowercase()
                        when (name) {
                            "response" -> {
                                cur = mutableMapOf()
                                curIsDir = false
                                seenProps.clear()
                            }
                            "collection" -> curIsDir = true
                            "getcontentlength" -> cur?.put("size", parser.nextText())
                            "getlastmodified" -> cur?.put("modified", parser.nextText())
                            "getcontenttype" -> cur?.put("mime", parser.nextText())
                            "displayname" -> cur?.put("displayname", parser.nextText())
                            "href" -> cur?.put("href", parser.nextText())
                        }
                    }
                    XmlPullParser.END_TAG -> {
                        if (parser.name.equals("response", true)) {
                            val c = cur
                            if (c != null) {
                                val href = c["href"]
                                if (href != null) {
                                    val path = hrefToPath(href)
                                    if (path.isNotEmpty()) {
                                        val name = c["displayname"]?.takeIf { it.isNotBlank() }
                                            ?: path.trimEnd('/').substringAfterLast('/')
                                        out.add(
                                            DavEntry(
                                                path = path,
                                                name = name,
                                                isDir = curIsDir,
                                                size = c["size"]?.toLongOrNull() ?: 0L,
                                                modified = parseHttpDate(c["modified"]),
                                                mime = c["mime"].orEmpty()
                                            )
                                        )
                                    }
                                }
                            }
                            cur = null
                        }
                    }
                }
                event = parser.next()
            }
        } catch (_: Throwable) {
        }
        return out
    }

    private fun hrefToPath(href: String): String {
        var h = href.trim()
        try {
            if (h.startsWith("http://") || h.startsWith("https://")) {
                val u = h.toHttpUrl()
                h = u.encodedPath
            }
        } catch (_: Throwable) {
        }
        val basePath = try {
            baseHttpUrl().encodedPath.trimEnd('/')
        } catch (_: Throwable) {
            ""
        }
        if (basePath.isNotEmpty() && h.startsWith(basePath)) h = h.substring(basePath.length)
        val decoded = percentDecode(h)
        return if (decoded.startsWith("/")) decoded else "/$decoded"
    }

    private fun percentDecode(s: String): String {
        val raw = s.toByteArray(Charsets.UTF_8)
        val out = ByteArrayOutputStream(raw.size)
        var i = 0
        while (i < raw.size) {
            val c = raw[i].toInt() and 0xFF
            if (c == '%'.code && i + 2 < raw.size) {
                val hi = Character.digit(raw[i + 1].toInt().toChar(), 16)
                val lo = Character.digit(raw[i + 2].toInt().toChar(), 16)
                if (hi >= 0 && lo >= 0) {
                    out.write(hi * 16 + lo)
                    i += 3
                    continue
                }
            }
            out.write(c)
            i++
        }
        return String(out.toByteArray(), Charsets.UTF_8)
    }

    private fun parseHttpDate(s: String?): Long {
        if (s.isNullOrBlank()) return 0L
        return try {
            val fmt = java.text.SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", java.util.Locale.US)
            fmt.parse(s)?.time ?: 0L
        } catch (_: Throwable) {
            0L
        }
    }

    companion object {
        const val UA = "FanjuBox/1.0 (Android; WebDAV)"

        val VIDEO_EXT = setOf(
            "mp4", "mkv", "webm", "avi", "mov", "flv", "ts", "m2ts", "mts", "wmv",
            "rmvb", "rm", "mpg", "mpeg", "m4v", "3gp", "ogv", "iso"
        )
        val SUB_EXT = setOf("srt", "ass", "ssa", "vtt", "sub", "idx")
        val DANMAKU_EXT = setOf("xml", "json")

        fun isVideo(name: String): Boolean = name.substringAfterLast('.', "").lowercase() in VIDEO_EXT
        fun isSubtitle(name: String): Boolean = name.substringAfterLast('.', "").lowercase() in SUB_EXT
        fun isDanmaku(name: String): Boolean = name.substringAfterLast('.', "").lowercase() in DANMAKU_EXT
    }
}

class WebDavException(message: String) : Exception(message)
