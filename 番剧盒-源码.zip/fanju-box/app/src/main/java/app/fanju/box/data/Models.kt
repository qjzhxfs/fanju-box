package app.fanju.box.data

import org.json.JSONArray
import org.json.JSONObject

data class MediaSource(
    val id: String,
    val type: String,          // "webdav" or "local"
    val name: String,
    val baseUrl: String = "",
    val user: String = "",
    val pass: String = "",
    val rootPath: String = "",
    val treeUri: String = ""
) {
    val isDav get() = type == "webdav"

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("type", type)
        put("name", name)
        put("baseUrl", baseUrl)
        put("user", user)
        put("pass", pass)
        put("rootPath", rootPath)
        put("treeUri", treeUri)
    }

    companion object {
        fun fromJson(o: JSONObject) = MediaSource(
            id = o.optString("id"),
            type = o.optString("type", "webdav"),
            name = o.optString("name"),
            baseUrl = o.optString("baseUrl"),
            user = o.optString("user"),
            pass = o.optString("pass"),
            rootPath = o.optString("rootPath"),
            treeUri = o.optString("treeUri")
        )
    }
}

data class MediaEpisode(
    val id: String,
    val sourceId: String,
    val path: String,
    val name: String,
    val size: Long = 0L,
    val number: Int = 0,
    val durationMs: Long = 0L,
    val subs: List<String> = emptyList(),
    val danmakuFiles: List<String> = emptyList()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("sourceId", sourceId)
        put("path", path)
        put("name", name)
        put("size", size)
        put("number", number)
        put("durationMs", durationMs)
        put("subs", JSONArray().also { arr -> subs.forEach { arr.put(it) } })
        put("danmakuFiles", JSONArray().also { arr -> danmakuFiles.forEach { arr.put(it) } })
    }

    companion object {
        fun fromJson(o: JSONObject) = MediaEpisode(
            id = o.optString("id"),
            sourceId = o.optString("sourceId"),
            path = o.optString("path"),
            name = o.optString("name"),
            size = o.optLong("size"),
            number = o.optInt("number"),
            durationMs = o.optLong("durationMs"),
            subs = o.optJSONArray("subs").toStringList(),
            danmakuFiles = o.optJSONArray("danmakuFiles").toStringList()
        )
    }
}

data class Work(
    val id: String,
    val sourceId: String,
    val folderPath: String,
    val rawTitle: String,
    val title: String = "",
    val summary: String = "",
    val poster: String = "",
    val backdrop: String = "",
    val year: String = "",
    val score: Double = 0.0,
    val bangumiId: Int = 0,
    val episodes: List<MediaEpisode> = emptyList(),
    val scannedAt: Long = 0L,
    val season: Int = 1
) {
    val displayTitle: String get() = title.ifBlank { rawTitle }
    val episodeCount: Int get() = episodes.size

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("sourceId", sourceId)
        put("folderPath", folderPath)
        put("rawTitle", rawTitle)
        put("title", title)
        put("summary", summary)
        put("poster", poster)
        put("backdrop", backdrop)
        put("year", year)
        put("score", score)
        put("bangumiId", bangumiId)
        put("scannedAt", scannedAt)
        put("season", season)
        put("episodes", JSONArray().also { arr -> episodes.forEach { arr.put(it.toJson()) } })
    }

    companion object {
        fun fromJson(o: JSONObject): Work {
            val eps = mutableListOf<MediaEpisode>()
            val arr = o.optJSONArray("episodes")
            if (arr != null) for (i in 0 until arr.length()) eps.add(MediaEpisode.fromJson(arr.getJSONObject(i)))
            return Work(
                id = o.optString("id"),
                sourceId = o.optString("sourceId"),
                folderPath = o.optString("folderPath"),
                rawTitle = o.optString("rawTitle"),
                title = o.optString("title"),
                summary = o.optString("summary"),
                poster = o.optString("poster"),
                backdrop = o.optString("backdrop"),
                year = o.optString("year"),
                score = o.optDouble("score", 0.0),
                bangumiId = o.optInt("bangumiId"),
                episodes = eps,
                scannedAt = o.optLong("scannedAt"),
                season = o.optInt("season", 1)
            )
        }
    }
}

internal fun JSONArray?.toStringList(): List<String> {
    if (this == null) return emptyList()
    val out = ArrayList<String>(length())
    for (i in 0 until length()) out.add(optString(i))
    return out
}

data class DavEntry(
    val path: String,
    val name: String,
    val isDir: Boolean,
    val size: Long = 0L,
    val modified: Long = 0L,
    val mime: String = ""
)

data class BgmSubject(
    val id: Int,
    val name: String,
    val nameCn: String,
    val summary: String,
    val poster: String,
    val score: Double,
    val date: String
)

data class AppSettings(
    val danmakuEnabled: Boolean = true,
    val danmakuBaseUrl: String = "",
    val danmakuAppId: String = "",
    val danmakuAppSecret: String = "",
    val scrapeEnabled: Boolean = true,
    val autoScanOnStart: Boolean = true,
    val preferNameCn: Boolean = true
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("danmakuEnabled", danmakuEnabled)
        put("danmakuBaseUrl", danmakuBaseUrl)
        put("danmakuAppId", danmakuAppId)
        put("danmakuAppSecret", danmakuAppSecret)
        put("scrapeEnabled", scrapeEnabled)
        put("autoScanOnStart", autoScanOnStart)
        put("preferNameCn", preferNameCn)
    }

    companion object {
        fun fromJson(o: JSONObject) = AppSettings(
            danmakuEnabled = o.optBoolean("danmakuEnabled", true),
            danmakuBaseUrl = o.optString("danmakuBaseUrl"),
            danmakuAppId = o.optString("danmakuAppId"),
            danmakuAppSecret = o.optString("danmakuAppSecret"),
            scrapeEnabled = o.optBoolean("scrapeEnabled", true),
            autoScanOnStart = o.optBoolean("autoScanOnStart", true),
            preferNameCn = o.optBoolean("preferNameCn", true)
        )
    }
}
