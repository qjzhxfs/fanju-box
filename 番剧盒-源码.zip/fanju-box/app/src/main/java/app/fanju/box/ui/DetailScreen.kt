package app.fanju.box.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.fanju.box.data.BgmSubject
import app.fanju.box.data.Repo
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DetailScreen(workId: String, onBack: () -> Unit, onPlay: (Int) -> Unit) {
    val works by Repo.works.collectAsState()
    val work = works.firstOrNull { it.id == workId }
    val scope = rememberCoroutineScope()
    var expanded by remember { mutableStateOf(false) }
    var showMatch by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }

    if (work == null) {
        EmptyHint("条目不存在", "可能已经被重新扫描移除", Modifier.fillMaxSize())
        return
    }

    val watchedCount = work.episodes.count { Repo.progressOf(it.id) > 0 }
    val nextIndex = work.episodes.indexOfFirst { Repo.progressOf(it.id) == 0L && it.durationMs > 0 }
        .let { if (it >= 0) it else work.episodes.indexOfFirst { Repo.progressOf(it.id) == 0L } }
        .let { if (it >= 0) it else 0 }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(260.dp)
        ) {
            if (work.poster.isNotBlank()) {
                PosterImage(
                    poster = work.poster,
                    label = work.displayTitle,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = androidx.compose.ui.layout.ContentScale.Crop
                )
            } else {
                Box(Modifier.fillMaxSize().background(CardBg2))
            }
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xCC0E0E11), Color(0x660E0E11), Bg)
                        )
                    )
            )
            IconButton(onClick = onBack, modifier = Modifier.padding(6.dp)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回", tint = Color.White)
            }
            Column(
                Modifier
                    .align(Alignment.BottomStart)
                    .padding(16.dp)
            ) {
                Text(
                    work.displayTitle,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (work.year.isNotBlank()) MetaChip(work.year)
                    if (work.score > 0) MetaChip("★ %.1f".format(work.score))
                    MetaChip("${work.episodeCount} 集")
                    if (watchedCount > 0) MetaChip("已看 $watchedCount")
                }
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { onPlay(nextIndex) },
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.size(6.dp))
                Text(
                    if (watchedCount > 0 && watchedCount < work.episodeCount) "继续观看 第${nextIndex + 1}集"
                    else if (watchedCount >= work.episodeCount && work.episodeCount > 0) "重新观看"
                    else "播放"
                )
            }
            OutlinedButton(enabled = !busy, onClick = { showMatch = true }) {
                Text("刮削匹配")
            }
        }

        if (work.summary.isNotBlank()) {
            Column(Modifier.padding(16.dp)) {
                Text("简介", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Text(
                    work.summary,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = if (expanded) Int.MAX_VALUE else 4,
                    lineHeight = 19.sp
                )
                Text(
                    if (expanded) "收起" else "展开",
                    fontSize = 12.sp,
                    color = Gold,
                    modifier = Modifier
                        .padding(top = 4.dp)
                        .clickable { expanded = !expanded }
                )
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("选集", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
            Text(
                "重新刮削",
                fontSize = 12.sp,
                color = Gold,
                modifier = Modifier.clickable {
                    scope.launch {
                        busy = true
                        val hit = Repo.searchBangumi(work.rawTitle).firstOrNull()
                        if (hit != null) Repo.applySubject(work.id, hit) else Repo.generateThumb(work)
                        busy = false
                    }
                }
            )
        }
        Spacer(Modifier.height(10.dp))

        FlowRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            work.episodes.forEachIndexed { idx, ep ->
                val watched = Repo.progressOf(ep.id) > 0
                Box(
                    Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (watched) Color(0xFF3A2E12) else CardBg2)
                        .clickable { onPlay(idx) }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = if (ep.number > 0) ep.number.toString().padStart(2, '0') else "${idx + 1}",
                        fontSize = 13.sp,
                        color = if (watched) Gold else Color.White
                    )
                }
            }
        }

        Spacer(Modifier.height(20.dp))
        Column(Modifier.padding(horizontal = 16.dp)) {
            Text(
                "来源：${Repo.sources.value.firstOrNull { it.id == work.sourceId }?.name ?: "未知"}",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                "路径：${work.folderPath}",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (busy) {
                Spacer(Modifier.height(8.dp))
                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
            }
        }
        Spacer(Modifier.height(30.dp))
    }

    if (showMatch) {
        MatchDialog(
            workId = work.id,
            initialKeyword = Repo.cleanTitle(work.rawTitle),
            onDismiss = { showMatch = false },
            onApplied = { showMatch = false }
        )
    }
}

@Composable
private fun MetaChip(text: String) {
    Text(
        text,
        fontSize = 11.sp,
        color = Color(0xFFE0E0E6),
        modifier = Modifier
            .padding(end = 6.dp)
            .background(Color(0x33FFFFFF), RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MatchDialog(
    workId: String,
    initialKeyword: String,
    onDismiss: () -> Unit,
    onApplied: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var keyword by remember { mutableStateOf(initialKeyword) }
    var results by remember { mutableStateOf<List<BgmSubject>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    var applied by remember { mutableIntStateOf(0) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("刮削匹配") },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = keyword,
                        onValueChange = { keyword = it },
                        label = { Text("番剧名称") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(enabled = !searching, onClick = {
                        searching = true
                        scope.launch {
                            results = Repo.searchBangumi(keyword)
                            searching = false
                        }
                    }) { Text("搜索") }
                }
                Spacer(Modifier.height(8.dp))
                if (searching) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.size(8.dp))
                        Text("搜索中…", fontSize = 12.sp)
                    }
                }
                Column(Modifier.height(280.dp).verticalScroll(rememberScrollState())) {
                    results.forEach { r ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    scope.launch {
                                        Repo.applySubject(workId, r)
                                        applied++
                                        onApplied()
                                    }
                                }
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            PosterImage(
                                poster = r.poster,
                                label = r.nameCn.ifBlank { r.name },
                                modifier = Modifier.size(width = 46.dp, height = 64.dp)
                            )
                            Spacer(Modifier.size(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    r.nameCn.ifBlank { r.name },
                                    fontSize = 13.sp,
                                    maxLines = 2,
                                    color = Color.White
                                )
                                Text(
                                    "${r.date}  ★${"%.1f".format(r.score)}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                    if (results.isEmpty() && !searching) {
                        Text("没有结果，换个关键词试试", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("关闭") } }
    )
}
