package app.fanju.box.player

import android.util.Xml
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.io.StringReader

data class DanmakuItem(
    val timeMs: Long,
    val mode: Int,        // 1/2/3 滚动, 4 底部, 5 顶部
    val color: Int,
    val sizeSp: Int,
    val text: String
)

object DanmakuParser {

    fun parseFile(file: File): List<DanmakuItem> {
        val text = try {
            file.readText()
        } catch (_: Throwable) {
            return emptyList()
        }
        return if (text.trimStart().startsWith("<")) parseXml(text) else parseJson(text)
    }

    fun parseXml(text: String): List<DanmakuItem> {
        val out = mutableListOf<DanmakuItem>()
        try {
            val parser = Xml.newPullParser()
            parser.setInput(StringReader(text))
            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG && parser.name.equals("d", true)) {
                    val p = parser.getAttributeValue(null, "p")
                    val content = parser.nextText()
                    val parts = p?.split(',') ?: emptyList()
                    val t = parts.getOrNull(0)?.toDoubleOrNull() ?: -1.0
                    if (t >= 0 && content.isNotBlank()) {
                        out.add(
                            DanmakuItem(
                                timeMs = (t * 1000).toLong(),
                                mode = parts.getOrNull(1)?.toIntOrNull() ?: 1,
                                color = parts.getOrNull(2)?.toIntOrNull() ?: 0xFFFFFF,
                                sizeSp = parts.getOrNull(3)?.toIntOrNull()?.takeIf { it in 12..40 } ?: 20,
                                text = content.trim()
                            )
                        )
                    }
                }
                event = parser.next()
            }
        } catch (_: Throwable) {
        }
        return out
    }

    fun parseJson(text: String): List<DanmakuItem> {
        val out = mutableListOf<DanmakuItem>()
        try {
            val root = JSONObject(text)
            val arr = root.optJSONArray("comments") ?: root.optJSONArray("danmaku") ?: return emptyList()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val p = o.optString("p")
                val m = o.optString("m").ifBlank { o.optString("text") }
                val parts = p.split(',')
                val t = parts.getOrNull(0)?.toDoubleOrNull() ?: o.optDouble("time", -1.0)
                if (t >= 0 && m.isNotBlank()) {
                    out.add(
                        DanmakuItem(
                            timeMs = (t * 1000).toLong(),
                            mode = parts.getOrNull(1)?.toIntOrNull() ?: o.optInt("mode", 1),
                            color = parts.getOrNull(2)?.toIntOrNull() ?: o.optInt("color", 0xFFFFFF),
                            sizeSp = o.optInt("size", 20).takeIf { it in 12..40 } ?: 20,
                            text = m.trim()
                        )
                    )
                }
            }
        } catch (_: Throwable) {
        }
        return out
    }
}

/**
 * 弹幕排版：为每条弹幕预先分配轨道与滚动时长，避免运行时互相重叠。
 */
class DanmakuLayout(
    val items: List<DanmakuItem>,
    laneCount: Int = 6,
    density: Float = 3f
) {
    data class Prepared(val item: DanmakuItem, val lane: Int, val enterMs: Long, val leaveMs: Long)

    val lanes: Int = laneCount.coerceIn(3, 10)
    val prepared: List<Prepared>

    init {
        val sorted = items.sortedBy { it.timeMs }
        val laneFree = LongArray(lanes)
        val result = ArrayList<Prepared>(sorted.size)
        for (item in sorted) {
            val estWidth = (item.text.length * item.sizeSp * density * 0.8f).toLong()
            val speed = 0.06f * density      // px per ms
            val travel = ((estWidth + 1200 * density) / speed).toLong().coerceIn(4000, 14000)
            var lane = -1
            for (i in 0 until lanes) {
                if (laneFree[i] <= item.timeMs) {
                    lane = i
                    break
                }
            }
            if (lane < 0) continue
            // 同一轨道下一条要等这条尾巴离开右边界
            laneFree[lane] = item.timeMs + (estWidth / speed).toLong() + 500
            result.add(Prepared(item, lane, item.timeMs, item.timeMs + travel))
        }
        prepared = result
    }

    fun activeAt(posMs: Long): List<Prepared> {
        if (prepared.isEmpty()) return emptyList()
        val out = ArrayList<Prepared>(16)
        for (p in prepared) {
            if (p.leaveMs < posMs) continue
            if (p.enterMs > posMs) break
            out.add(p)
        }
        return out
    }
}
