package app.fanju.box.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Gold = Color(0xFFE8B44A)
val Bg = Color(0xFF0E0E11)
val CardBg = Color(0xFF191920)
val CardBg2 = Color(0xFF23232B)
val TextDim = Color(0xFF9A9AA5)

@Composable
fun FanjuTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Gold,
            onPrimary = Color.Black,
            primaryContainer = Color(0xFF3A2E12),
            onPrimaryContainer = Gold,
            secondary = Gold,
            background = Bg,
            onBackground = Color.White,
            surface = CardBg,
            onSurface = Color.White,
            surfaceVariant = CardBg2,
            onSurfaceVariant = TextDim,
            outline = Color(0xFF3A3A44)
        ),
        content = content
    )
}
