# 番剧盒（fanju-box）

给安卓手机用的 **WebDAV + 本地文件** 影视客户端。海报墙、Bangumi 刮削简介、播放器、外挂字幕、断点续播、弹幕、手势倍速。
**没有任何服务器功能**：不依赖 Emby/Jellyfin，直接读 WebDAV 或手机文件夹。

原需求来自 Tigerest Theater（Qt + Emby 客户端）。那套界面/数据层全部绑在 Emby API 上，所以这里按它「海报墙 + 刮削 + 播放器」的思路重做了一个安卓原生 App，
而不是去改 Qt 工程。

## 功能

| 模块 | 现状 |
| --- | --- |
| 媒体源 | WebDAV（Alist/OpenList、群晖、Nextcloud、坚果云…，Basic Auth）+ 手机本地文件夹（SAF，不需要存储权限） |
| 库扫描 | 递归找视频，按文件夹聚合成「番剧」，文件名解析集数（`01`／`第1集`／`S01E01`／`EP05`），自然排序，自动跳过 QQ/Telegram/下载 等垃圾目录 |
| 刮削 | Bangumi 公开 API：中文名、简介、封面、评分、年份，按文件夹名自动匹配；可手动搜索纠正（详情页「刮削匹配」）；刮削不到时用视频帧当封面 |
| 海报墙 | 自适应列数、评分角标、已看进度条、集数 |
| 详情页 | 背景大图 + 海报、简介展开、来源路径、选集网格、继续观看 |
| 播放 | Media3/ExoPlayer，支持 WebDAV 直链（带鉴权头）与 `content://` 本地文件，自动播放、断点续播、上一集/下一集 |
| 字幕 | 同目录 srt/ass/ssa/vtt 自动匹配加载（支持「整目录共用一条字幕」的合集），内嵌字幕轨道 + 字幕开关 |
| 弹幕 | 同目录 bilibili XML / 弹弹play JSON 自动加载；设置里填弹弹play AppId/Secret 还能按番剧名拉网络弹幕；自绘弹幕层，滚动/顶部弹幕按轨道排布 |
| 手势 | 左右滑快进快退（带时间预览）、左半边上下滑亮度、右半边上下滑音量、长按 3x 快进、单击显示/隐藏控制栏、双击播放暂停、锁定后点击解锁 |
| 其它 | 沉浸式播放（隐藏系统栏）、倍速 1/1.25/1.5/2/3x、播放进度每 5 秒落盘 |

## 项目结构

```
app/src/main/java/app/fanju/box/
├── MainActivity.kt            # 单 Activity + 手写导航（Home/Detail/Player/Settings）
├── data/
│   ├── Models.kt              # MediaSource / MediaEpisode / Work / DavEntry / AppSettings
│   ├── Store.kt               # JSON 落盘（媒体源、库、进度、设置、手动刮削覆盖）
│   ├── WebDav.kt              # 极简 WebDAV 客户端（PROPFIND 解析、下载、URL 构造）
│   ├── Bangumi.kt             # Bangumi 刮削 + 弹弹play 网络弹幕
│   ├── Thumbnails.kt          # MediaMetadataRetriever 抓帧/取时长
│   └── LibraryRepository.kt   # 扫描聚合、刮削队列、播放参数准备
├── player/Danmaku.kt          # 弹幕解析 + 轨道排布
└── ui/                        # Compose 界面：海报墙、详情、播放器、设置、添加源
```

数据都在应用私有目录：`/data/data/app.fanju.box/files/library/*.json`，海报缓存在 `files/posters/`。

## 构建（本机环境已踩通的坑）

容器里没有 sdkmanager/gradle，下面是能跑通的组合：

1. **JDK 17**（`/usr/lib/jvm/java-17-openjdk-arm64`）。系统自带的 21 是 JRE，没有 javac，AGP 会报 `does not provide JAVA_COMPILER`。
2. **Gradle 8.13**：`/opt/gradle-8.13/bin/gradle`，必须设 `JAVA_TOOL_OPTIONS=-Dfile.encoding=UTF-8`（否则中文路径 `InvalidPathException`），以及
   `-Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts`（默认 truststore 是空的，HTTPS 会静默失败）。
3. **Android SDK**：platform-36 + build-tools 36.0.0 手工解包到 `/opt/android-sdk`（`platforms/android-36`、`build-tools/36.0.0`），`local.properties` 写 `sdk.dir`。
4. **aapt2**：官方 build-tools 只有 x86_64，arm64 容器里跑不了。做法是 qemu 包装：
   ```sh
   /opt/aapt2-qemu/aapt2        # exec qemu-x86_64-static -L /opt/android-sdk/amd64-root .../build-tools/36.0.0/aapt2 "$@"
   ```
   并在 `gradle.properties` 里 `android.aapt2FromMavenOverride=/opt/aapt2-qemu/aapt2`（文件名必须叫 aapt2）。
   amd64 运行库来自 apt 下载的 `libc6/libstdc++6/libgcc-s1/zlib1g` deb，解到 `/opt/android-sdk/amd64-root`。
5. **依赖下载**：Gradle 自带 HTTP 客户端在这里会截断大文件（`Premature end of Content-Length`），所以跑一个本地 Maven 代理
   `python3 maven_proxy.py 8099`（curl 下载 + 校验 + 缓存），`settings.gradle.kts` 指向 `http://127.0.0.1:8099/gcs|pub|gradle`。

构建命令：

```sh
cd /root/work/fanju
export ANDROID_HOME=/opt/android-sdk
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-arm64
export JAVA_TOOL_OPTIONS="-Dfile.encoding=UTF-8 -Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts -Djavax.net.ssl.trustStorePassword=changeit"
/opt/gradle-8.13/bin/gradle --no-daemon assembleDebug
# 产物：app/build/outputs/apk/debug/app-debug.apk
```

装到手机：把 APK 放到 `/sdcard/Download/`，文件管理里点开 → 允许「文件管理」安装 →（小米会提示未备案）继续安装 → 继续更新。
`pm install` 被设备策略禁用，只能走系统安装器。

## 2026-11-08 这轮修的问题

- 集数解析重写：`[组] 番名 - 01 [WebRip 1080p HEVC-10bit AAC ASSx2].mkv` 以前会被 `10bit`/`x2` 里的数字带偏，整季都显示 02；现在按
  `SxxExx` → `第N集` → ` - NN` → `[NN]` → `EPxx` →（去标签后）最后一个独立数字 的顺序解析，实测 01…13 全部正确。
- 快进范围改为按片长自适应：全屏宽度 ≈ 片长的 8%，夹在 60s–600s 之间（原来固定 90s，长片几乎滑不动）。
- 长按 3x 加了保护：手势被系统打断时会复位倍速（之前可能一直 3x 播到结尾）；控制栏倍速按钮在长按时显示 `3.0x（长按）`。
- 添加媒体源的输入框都加了「粘贴」按钮（手机上手输 WebDAV 地址/密码太容易出错）。
- 扫描会跳过 QQ / Telegram / 微信 / Download / 缓存 等垃圾目录。
- 首页海报墙改为自适应列数；播放页进入时隐藏系统栏。
- 手势/进度相关埋了 `Log.i("fanju-gesture", ...)`，方便以后在 logcat 里核对。

## 2026-11-08 第二轮（用户真机反馈）

- **长按 3x 太慢**：原来用「按住时计时」判定，但安卓在手指不动时根本不派发 move 事件，计时永远走不到；改成按下即启动 300ms 定时任务（`rememberCoroutineScope().launch`），到点触发 3x 并震动反馈（`HapticFeedbackConstants.LONG_PRESS`），松手/滑动/取消都会撤销。
- **画面拉伸**：播放器原来把 SurfaceView 直接铺满窗口，非 16:9 片源会被拉伸。改用 `androidx.media3.ui.AspectRatioFrameLayout`（`RESIZE_MODE_FIT`）包住 SurfaceView，按 `VideoSize` 实时设置比例，上下/左右自动留黑边。
- 设置页的弹幕 AppId / AppSecret / 服务地址也换成带「粘贴」按钮的输入框。

## 本机验证记录（2026-11-08）

用用户自己的 Alist（`/dav`，根目录 `/openlist/动漫`）实测：

| 项 | 证据 |
| --- | --- |
| WebDAV 连接 | 添加源里「测试连接」返回「连接成功，发现 2 项」；扫描后 7 部番剧 |
| 刮削 | 7 部番剧全部拿到 Bangumi 封面、中文名、评分、简介（6.1–6.8）、年份 |
| 播放 | 《与你相恋到生命尽头》第 1/4/5 集、《黑暗召唤师》等直接串流播放 |
| 字幕 | 内嵌 ASS 双语字幕正常显示；测试服务上同目录 SRT 自动加载成功 |
| 断点续播 | 播到一半退出后详情页显示「已看 4 / 继续观看 第5集」，重进第 4 集从中段继续 |
| 手势 | 右滑快进后画面从花田跳到石屋（换场景，说明已跳转）；左半屏下滑后截帧平均亮度 150→58（亮度手势生效）；音量手势同理走系统音量 |
| 弹幕 | 测试目录里放 bilibili XML 后播放页出现滚动/顶部弹幕 |
| 集数 | 《与你相恋》13 个选集按钮显示 01–13 |

尚未拿到直接证据：**长按 3x 的实时提示帧**（注入手势的抓帧时序对不上，代码路径已加保护，建议手动长按确认一下）；**弹弹play 网络弹幕**（还没填 AppId/Secret）。

## 已知问题 / 下一步

- 手势、亮度音量这些没有自动化测试覆盖，只在真机上手工点过；双击播放/暂停和长按 3x 建议再验一遍。
- 网络弹幕（弹弹play）需要自己填 AppId/AppSecret，未实测；本地 XML/JSON 弹幕已验证。
- ASS 字幕按纯文本渲染（Media3 的 SsaDecoder），复杂特效/位置不会还原。
- 刮削按文件夹名匹配，遇到「S2」「续篇」这类需要手动搜索纠正；目前只在详情页提供单个条目的「刮削匹配」。
- 没有离线缓存：WebDAV 播放是直连流式，网盘慢时需要等缓冲。
- 本地文件源走 SAF，Android 16 不允许直接选 `Download` 根目录（系统限制），选上级或其它目录即可。
