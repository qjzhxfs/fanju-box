pluginManagement {
    repositories {
        maven { url = uri("http://127.0.0.1:8099/gradle"); isAllowInsecureProtocol = true }
        maven { url = uri("http://127.0.0.1:8099/gcs"); isAllowInsecureProtocol = true }
        maven { url = uri("http://127.0.0.1:8099/pub"); isAllowInsecureProtocol = true }
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositories {
        maven { url = uri("http://127.0.0.1:8099/gcs"); isAllowInsecureProtocol = true }
        maven { url = uri("http://127.0.0.1:8099/pub"); isAllowInsecureProtocol = true }
        google()
        mavenCentral()
    }
}
rootProject.name = "fanju"
include(":app")
